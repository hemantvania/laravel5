<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserRoles;

class UsersController extends Controller
{
    /*public function login()
    {
        view('auth.login');
    }
    public function register(){
        $roles = UserRoles::all();
        return view('auth.register', compact('roles'));
    }

    public function create(Request $request)
    {
        echo "<pre>"; print_r($request->all());
        die();
    }*/
}
