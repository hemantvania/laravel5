        
        <?php $__env->startSection('content'); ?>   
           <div class="content">
               <div class="container">
                   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php echo e($user->name); ?>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
                       <?php echo e($users->links()); ?>

               <?php echo e($users->appends(['sort' => 'role'])->links()); ?>

               <?php echo e($users->fragment('role')->links()); ?>

                           <div class="links">
                               <a href="https://laravel.com/docs">Documentation</a>
                               <a href="https://laracasts.com">Laracasts</a>
                               <a href="https://laravel-news.com">News</a>
                               <a href="https://forge.laravel.com">Forge</a>
                               <a href="https://github.com/laravel/laravel">GitHub</a>
                           </div>
                       </div>
                   <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>