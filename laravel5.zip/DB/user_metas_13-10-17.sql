/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.7.14 : Database - laravel5
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`laravel5` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `laravel5`;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values (6,'2017_11_15_122438_create_userrole_table',1),(10,'2017_11_15_115505_add_userrole_to_users',2),(12,'2017_12_01_111509_add_mobile_no_to_users_table',3);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `userroles` */

DROP TABLE IF EXISTS `userroles`;

CREATE TABLE `userroles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `userroles` */

insert  into `userroles`(`id`,`role`,`status`,`created_at`,`updated_at`) values (1,'Admin',1,NULL,NULL),(2,'School Admin',1,NULL,NULL),(3,'School District',1,NULL,NULL),(4,'Teacher',1,NULL,NULL),(5,'Student',1,NULL,NULL);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(10) unsigned NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_mobile_no_unique` (`mobile_no`),
  KEY `users_role_foreign` (`role`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`password`,`mobile_no`,`role`,`remember_token`,`created_at`,`updated_at`) values (1,'Hemant Kumar','hemant@gtl.com','$2y$10$z8iPfFjBi.amRLnvbmXRceLBQuELcfD.q9uDgBF22j4Sur7dbuCRa',NULL,0,'Ce3D9wklj7Gv4exIzuDscCjuo2gi0z6wD4AHOjq5EDktDqtUxVOm4CmEnp0V','2017-11-15 13:56:57','2017-11-15 13:56:57'),(2,'School Admin','schooladmin@gtl.com','$2y$10$A.m6o/eszCBJ.4XzS4fDru0kO5oWBbu4VjCN3HMZ7Oo2q9Mv3xwQm',NULL,0,NULL,'2017-11-15 13:57:56','2017-11-15 13:57:56'),(3,'Hemant Vaniya','himatlal.vaniya@gatewaytechnolabs.com','$2y$10$mjmEDQ5WBHrGJ08Z08W2meLERIWAcMfCOahPfhwC1Ca6GoRqk/jku',NULL,0,'p8W15nX8U3zFHPUCEW3odqBO1rDtEIpRkliQIhZ4T5Ww3728mRZHFSeYAe8k','2017-11-18 04:55:42','2017-11-29 09:08:32'),(4,'Hemant','hemantvania@gmail.com','$2y$10$9gXzkejjeW.HLpeiV6qPoOLOzVoetWm7zobiQoFdb.8UAMd7r0V6q','9913306895',1,'pp3uloX9WTKUB47WkeBMCAuSvUR8tKzZkhcnMdjSE8ujoAVlFpGhNwX48bNW','2017-12-01 11:36:33','2017-12-01 11:36:33');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
